# Auditoría técnica final — NutriFamilia V7.1.2

## Objetivo
Cerrar la versión de prueba del dashboard con el comportamiento solicitado: indicadores tipo velocímetro, con una aguja que recorre un arco semicircular para mostrar el avance de calorías y macronutrientes.

## Correcciones aplicadas
- Eliminada la implementación duplicada de `renderHome()` que permanecía en `js/ui/ui.js`. El dashboard queda con un único propietario: `js/ui/dashboard.js`.
- Corregido el recorrido angular de la aguja: 0% = -90°, 50% = 0°, 100% = +90°. Los valores fuera de rango se limitan visualmente a los extremos.
- Mantenidos los valores numéricos de exceso para que el límite visual del instrumento no oculte el sobreconsumo.
- Añadidos casos de autoprueba para 0%, 50%, 100%, >100% y valores negativos.
- Añadidos alias de variables CSS para eliminar referencias heredadas no definidas (`--surface`, `--primary`, `--nf-surface-2`).
- Conservada la clave histórica de `localStorage` y el modelo de datos.
- No se modificaron valores nutricionales ni se inventaron equivalencias de unidades.
- Actualizada la versión a V7.1.2 en runtime, manifest, service worker y documentación.

## Arquitectura
- HTML, CSS y JS permanecen separados.
- El dashboard vive en su módulo propio.
- El motor nutricional no depende de la presentación visual.
- Las funciones existentes de comidas, recetas, salud, IA, voz, importación/exportación y navegación permanecen en sus módulos respectivos.

## Validación automatizada realizada
- `node --check`: todos los archivos JavaScript válidos.
- Manifest JSON: válido.
- Referencias locales de HTML: válidas.
- Sin etiquetas `<style>` inline en `index.html`.
- Sin bloques `<script>` inline en `index.html`.
- Harness de ejecución JavaScript con DOM/localStorage simulados: carga e inicialización correctas.
- Autoprueba interna de la aplicación: **36/36 OK**.
- Matemática de aguja: verificada para extremos, centro y saturación.
- Base nutricional: validaciones internas existentes superadas en el harness.

## Prueba de navegador
Se intentó una ejecución headless de Chromium mediante servidor local. El proceso no completó por una limitación del entorno de ejecución (bloqueo/timeout de zygote/DBus). Por ese motivo no se declara una validación visual completa en navegador ni equivalencia pixel-perfect.

## Estado
**V7.1.2 — candidato listo para prueba en teléfono/navegador real.**

La siguiente validación necesaria es práctica: crear un perfil, registrar alimentos, comprobar que las agujas avanzan correctamente, superar objetivos, editar/eliminar entradas y verificar persistencia tras recargar la aplicación.
