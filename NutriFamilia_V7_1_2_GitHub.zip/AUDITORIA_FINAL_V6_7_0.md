# NutriFamilia V6.7.0 — Auditoría final de overhaul

## Alcance

Esta versión integra el rediseño funcional y visual solicitado para una PWA móvil simple, con una interfaz original inspirada en patrones de UX de apps modernas de nutrición: resumen diario visible, macronutrientes agrupados, comidas por bloques, acciones rápidas y registro de alimentos con menos fricción.

La versión mantiene el namespace de almacenamiento `nutrifamilia_v6_6_6_standalone` de forma deliberada para no romper los datos locales existentes al actualizar desde V6.6.6. El nombre de versión de software pasa a 6.7.0 y el Service Worker usa un caché nuevo.

## Cambios funcionales principales

- Inicio rediseñado: calorías consumidas hoy vs objetivo, proteína/hidratos/grasas/fibra juntos, comidas separadas y acciones rápidas.
- Comidas: búsqueda, favoritos, recientes, mis alimentos, texto/voz y código de barras desde el mismo flujo.
- Alta de alimento: sin selección automática de un alimento arbitrario; el usuario debe elegir uno explícitamente.
- Unidades: gramos por defecto y unidades/porciones solo cuando la base tiene equivalencia documentada.
- Huevo crudo: 1 unidad se transforma matemáticamente a 50 g de huevo sin cáscara en el registro utilizado, y 2 unidades a 100 g.
- Nuevos ingredientes en estado crudo: huevo, cebolla, pimiento verde, zapallito, tomate y pechuga de pollo.
- Recetas: empiezan sin ingredientes, se agregan uno a uno, permiten eliminar ingredientes, editar ingredientes, elegir unidad y recalcular el total y el valor por porción.
- Agua: `+250 ml`, `-250 ml` y edición directa con límites de 0 a 10.000 ml.
- Favoritos: se pueden marcar/desmarcar desde el flujo de alta y luego aparecen como acceso rápido.
- Recientes: se muestran como accesos rápidos cuando existen registros previos.
- Mis alimentos: creación manual visible y gestión de los alimentos personalizados.
- Código de barras: el producto localizado puede pasar directamente al flujo de `Agregar alimento`; Open Food Facts se trata como dato de producto/etiqueta, no como fuente científica primaria.
- Texto/voz: voz a texto y análisis local se separan. La interpretación local funciona sin IA para expresiones simples; la IA queda como mejora opcional.
- Progreso: se separan explícitamente consumo de hoy, promedio de 7 días, gasto energético estimado y objetivo diario.
- Promedio semanal: el denominador es fijo de 7 días; no se divide por la cantidad de días con registros.

## Base de datos de alimentos

La base queda en 104 alimentos en la batería local de esta release. La arquitectura distingue alimento/estado y permite representar datos por 100 g o por porción/unidad.

Se conservaron los controles de calidad de la versión anterior: no convertir micronutrientes ausentes en cero, no presentar azúcares totales como azúcares libres, no presentar el agua de referencia como agua potable exclusivamente y no convertir una estimación de gasto en una medición metabólica.

Los nuevos alimentos crudos se etiquetan con estado y fuente. La composición nutricional se expresa sobre una base de referencia y se escala matemáticamente según la cantidad ingresada.

Importante: la base general de 104 alimentos no debe declararse clínicamente equivalente a una base nacional completa. Los registros nuevos y los existentes siguen una política conservadora de fuente y calidad, pero los datos que no cuentan con trazabilidad alimento-por-alimento primaria siguen siendo provisionales.

## Pruebas automatizadas ejecutadas

### Sintaxis e integridad

- `node --check` del JavaScript embebido: PASS.
- `node --check` del Service Worker: PASS.
- Manifest JSON: PASS.
- Funciones duplicadas: 0.
- IDs HTML estáticos repetidos: no se consideran fallos de runtime; los identificadores dinámicos usados por formularios modales pueden aparecer en más de una plantilla, pero no simultáneamente.
- Búsqueda de patrones de credenciales tipo `sk-...`: sin hallazgos.
- El cliente no envía `Authorization: Bearer` directamente.

### Motor nutricional

- 104 alimentos cargados.
- 104/104 admiten metadatos compatibles con `per100g` o `portion` en la batería local.
- Valores clave de huevo crudo: 148 kcal, 12.4 g proteína, 1.0 g hidratos y 10.0 g grasa por 100 g en la referencia utilizada.
- 1 huevo crudo registrado por unidad: 50 g y ~74 kcal.
- 2 huevos crudos por unidad: 100 g.
- 200 g de pechuga de pollo cocida de la base: 302 kcal.
- Cantidades 0, negativas e infinitas: rechazadas.
- Receta de prueba `2 huevos crudos + 100 g cebolla cruda`: calcula ~188 kcal, 13.5 g proteína, 10.34 g hidratos y 10.1 g grasa; micronutrientes no disponibles continúan marcados como desconocidos.

### UX / funciones críticas

- Inicio: renderizado por harness: PASS.
- Comidas: renderizado por harness: PASS.
- Progreso: renderizado por harness: PASS.
- Peso: renderizado por harness: PASS.
- Perfil: renderizado por harness: PASS.
- Autoprueba integrada: 31/31 PASS.
- Parser local: `2 huevos crudos, 100 g cebolla` reconoce el huevo crudo por unidad y la cebolla por gramos en la arquitectura de registro.

## Prueba de navegador real

Se intentó ejecutar Chromium headless contra un servidor HTTP local. En este entorno el proceso no terminó dentro del límite operativo y no produjo DOM exportable; por lo tanto, esta prueba no se cuenta como PASS.

La validación funcional positiva de release se basa en `node --check`, harness de runtime, harness de UI y autoprueba interna. Antes de convertir a Android se recomienda una última pasada de prueba manual en el mismo teléfono que se utilizará para producción.

## Evidencia y fuentes nutricionales

- USDA FoodData Central: fuente de composición de alimentos y servicio orientado a integradores; el sitio oficial mantiene datos Foundation Foods, SR Legacy, FNDDS y Branded Foods y publica sus descargas y documentación.
- SARA 2 / ENNyS 2: referencia argentina utilizada por la arquitectura anterior cuando la correspondencia es adecuada.
- WHO, EFSA, Mifflin–St Jeor y guías de proteína/obesidad utilizadas en la lógica de objetivos, conservando el carácter orientativo de los cálculos.

## Limitaciones explícitas

1. Una base de 104 alimentos no es una base universal ni cubre todas las marcas, preparaciones ni tamaños.
2. Un alimento personalizado ingresado por el usuario se identifica como dato personalizado y no como composición científica primaria.
3. Open Food Facts es una fuente de información del producto/etiqueta; no reemplaza una tabla nacional de composición.
4. La equivalencia unidad→gramos solo debe aparecer cuando existe un peso de referencia documentado; no se usa una equivalencia arbitraria.
5. El estado `sin especificar` puede permanecer en registros antiguos cuyo nombre no aporta un estado inequívoco; los nuevos ingredientes crudos relevantes quedan explícitos.

## Criterio de release

La versión 6.7.0 queda preparada para la siguiente etapa de validación manual en GitHub Pages y posterior empaquetado Android. No se considera clínicamente certificada; la app es una herramienta de registro y orientación nutricional con cálculos transparentes y datos de calidad variable según la fuente.
