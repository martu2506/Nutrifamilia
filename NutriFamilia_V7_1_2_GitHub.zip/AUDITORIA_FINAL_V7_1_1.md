# Auditoría técnica — NutriFamilia V7.1.2

## Objetivo
V7.1.2 continúa el refactor modular de V7.1.0 y sustituye el indicador circular del dashboard por un **medidor semicircular con aguja**, orientado a representar el avance consumido respecto del objetivo diario.

## Cambios
- `js/ui/dashboard.js`: módulo independiente del dashboard; sobrescribe `renderHome()` sin volver a introducir lógica nutricional.
- `css/dashboard.css`: estilos exclusivos de los medidores y dashboard.
- Calorías: medidor semicircular principal con aguja, valor consumido, objetivo, restante/exceso y escala 0→objetivo.
- Macronutrientes: proteína, hidratos y grasas con medidores de aguja independientes.
- La representación visual se limita a 100% para evitar que la aguja salga del instrumento; el exceso no se pierde y se comunica en el valor numérico/texto.
- Se mantiene la clave histórica de `localStorage` para compatibilidad.
- No se modificaron valores nutricionales ni se inventaron equivalencias de unidades.
- Se conserva la navegación, comidas, agua, peso, consejos y calidad nutricional existentes.

## Validación estática
- Todos los JavaScript pasan `node --check`.
- Manifest JSON válido.
- CSS/JS locales referenciados por `index.html` existen.
- El nuevo módulo se carga después de `ui.js` y antes de `diagnostics.js`, por lo que `render()` utiliza el `renderHome()` actualizado.
- La matemática del indicador usa proporción `consumido/objetivo`; objetivos no positivos producen proporción 0.

## Limitación
No se realizó una prueba visual completa en navegador en este entorno. Por ello no se afirma equivalencia pixel-perfect con Fitia o Pulso. El diseño implementa el comportamiento solicitado —instrumento semicircular + aguja— sin copiar identidad, assets ni código propietario.
