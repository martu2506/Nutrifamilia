# NutriFamilia V7.0.1 — Auditoría de cierre

## Objetivo
Cierre técnico de V7 con correcciones de versión, unidades, persistencia, edición de comidas y una nueva identidad visual amarillo/negro de alto contraste.

## Correcciones aplicadas
- `manifest.webmanifest`: actualizado de V6.6.6 a V7.0.1.
- `sw.js`: caché actualizado a `nutrifamilia-v7.0.1` para forzar una separación clara del caché anterior.
- `index.html`, `VERSION.txt`, diagnóstico y autoprueba: V7.0.1 consistente.
- Se conserva deliberadamente la clave de almacenamiento `nutrifamilia_v6_6_6_standalone` para mantener los datos existentes; esto no representa la versión del código.
- Huevo crudo: la unidad documentada puede persistirse como unidad; `1 huevo` usa 50 g de referencia y no se degrada a 1 g al recargar.
- El selector de unidad aparece también al editar una comida.
- La edición guarda `inputUnit` y recalcula el alimento con la unidad seleccionada.
- Home incorpora `Editar` y eliminación directa por alimento en los primeros elementos de cada comida.
- Se agregó `deleteEntry`, requerido por el historial existente.
- El resolver local reconoce también `pollo`, `pechuga` y `pechuga de pollo`.
- Mifflin–St Jeor queda restringida a perfiles de 18–100 años, porque la ecuación original fue derivada en población adulta; no se extrapola automáticamente a adolescentes.
- `Factura` no recibe equivalencia inventada: continúa requiriendo gramos.

## Interfaz amarillo/negro
Se aplicó un tema de alto contraste:
- Fondo general: amarillo cálido claro.
- Texto y acciones principales: negro.
- Header y navegación inferior: negro.
- Tarjetas y formularios: blanco para mantener legibilidad y separación visual.
- Amarillo reservado también para chips/indicadores secundarios.

La decisión evita usar amarillo saturado como superficie de texto extensa, lo que reduce problemas de contraste y fatiga visual sin perder la identidad amarillo/negro.

## Integridad nutricional
- No se convierten nutrientes faltantes en cero.
- Las unidades sólo aparecen cuando existe una equivalencia registrada en la ficha.
- Los datos de Open Food Facts continúan identificados como datos de producto/etiqueta.
- Las metas energéticas/proteicas y ajustes adaptativos siguen marcados como estimaciones/configuraciones, no como prescripción clínica.
- Agua total y agua/bebidas registradas continúan diferenciadas.
- La referencia de frutas y verduras conserva el criterio de la OMS y no cuenta raíces feculentas como equivalentes automáticos.

## Validación ejecutada
- 3 bloques JavaScript de `index.html`: `node --check` PASS.
- `sw.js`: `node --check` PASS.
- `manifest.webmanifest`: JSON válido PASS.
- Búsqueda de versiones antiguas en código/manifest/sw/README: PASS; sólo permanece la clave de almacenamiento histórica de forma intencional.
- Se confirmó que el servidor HTTP local entrega `index.html` correctamente.
- Chromium headless volvió a quedar bloqueado por el entorno (timeout/DBus); por lo tanto no se afirma validación visual automática del navegador.

## Prueba de aceptación pendiente
La prueba final debe realizarse en GitHub Pages y en el teléfono: carga limpia de V7.0.1, alta de `1 huevo crudo` por unidad, recarga de la PWA, edición/eliminación de comidas, agua +/-/editar, recetas y actualización del Service Worker.
