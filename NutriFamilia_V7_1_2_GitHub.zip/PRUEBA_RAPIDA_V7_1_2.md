# Prueba rápida — NutriFamilia V7.1.2

## 1. Inicio
Crear un perfil y confirmar que aparece el dashboard.

## 2. Aguja de calorías
Registrar un alimento pequeño y comprobar que la aguja queda cerca del extremo izquierdo.
Registrar aproximadamente la mitad del objetivo y comprobar que queda cerca del centro.
Al llegar al objetivo debe quedar en el extremo derecho.
Si se supera el objetivo, debe permanecer en el extremo y mostrar el exceso en texto/número.

## 3. Macronutrientes
Agregar varios alimentos y verificar que proteína, hidratos y grasas actualizan sus propios indicadores.

## 4. Comidas
Abrir el detalle de una comida, editar cantidad/unidad, guardar y comprobar que se recalculan kcal y macros.
Eliminar una entrada y verificar que desaparece del total.

## 5. Unidades
Para alimentos con equivalencia documentada, comprobar que la unidad aparece en el selector.
Para alimentos sin equivalencia, comprobar que se mantiene la entrada por gramos.

## 6. Persistencia
Recargar la página y comprobar que el perfil y las comidas siguen presentes.

## 7. PWA
Desde un contexto HTTPS, comprobar instalación y navegación básica.
