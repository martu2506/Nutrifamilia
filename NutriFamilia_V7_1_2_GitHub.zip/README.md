# NutriFamilia V7.1.2

PWA nutricional familiar, modularizada desde V7.0.2 sin cambiar el modelo de datos ni la clave de localStorage.

## Arquitectura
- `index.html`: estructura y puntos de montaje UI.
- `css/`: estilos base, componentes, layout, accesibilidad y tema amarillo/negro.
- `js/data/`: datos nutricionales estáticos.
- `js/core/`: runtime, motor/base nutricional, persistencia/importación y diagnósticos.
- `js/features/`: salud, IA, comidas y recetas.
- `js/ui/`: renderizado y navegación.
- `js/compat.js`: compatibilidad/ajustes finales de la versión anterior.
- `manifest.webmanifest`, `sw.js`: PWA/offline.

## Compatibilidad de datos
La clave de `localStorage` se conserva intencionalmente para mantener los datos existentes entre versiones.


## V7.1.2 — Dashboard de progreso
- Dashboard principal rediseñado con medidor semicircular tipo velocímetro y aguja para calorías.
- Tres medidores con aguja para proteína, hidratos y grasas.
- La aguja se limita visualmente al 100%; el exceso se conserva en los valores numéricos.
- Se mantiene la clave de `localStorage`, el modelo nutricional y las equivalencias documentadas.
- Nuevo módulo `js/ui/dashboard.js` y hoja `css/dashboard.css`.
- No requiere credenciales de IA ni modifica datos nutricionales.


## Estado de la versión
V7.1.2 es el candidato de prueba actual. La validación automatizada pasa las autopruebas internas; la validación visual final debe hacerse en un navegador/teléfono real. Ver `PRUEBA_RAPIDA_V7_1_2.md`.
