# Auditoría de cierre NutriFamilia V7.0.2

## Cambios de esta build
- Manifest, Service Worker, runtime y VERSION.txt alineados en V7.0.2.
- `meta theme-color` corregido a #111111 para el tema amarillo/negro.
- Se eliminó la redefinición vacía de `lookupBarcode` del IIFE.
- Se redujo el renderizado completo: `render()` actualiza la pestaña activa y conserva el routing existente.
- Navegación y FAB con `aria-label`.
- Modal con `role=dialog`, `aria-modal`, foco inicial en cerrar y restauración del foco al cerrar.
- Variable CSS `--nf-card` mal tipada corregida a `--nf-card-radius`.
- Flujo de IA: el modelo queda opcional y puede ser definido por el proxy; no se presenta un identificador de API inventado como predeterminado.
- Parser local admite alias básicos como pollo/pechuga.
- Límite de 500 alimentos personalizados para reducir riesgo de cuota de localStorage; reemplazar un alimento existente no consume una posición adicional.
- Service Worker sin entrada redundante `./` en el shell precacheado.

## Salvaguardas nutricionales conservadas
- Unidades solo cuando existe equivalencia documentada.
- Huevo crudo: 1 unidad de referencia = 50 g sin cáscara.
- Micronutrientes faltantes no se imputan como cero.
- Agua registrada diferenciada de referencia de agua total.
- Valores de producto Open Food Facts permanecen identificados como datos de producto/etiqueta.
- Mifflin–St Jeor se usa en adultos.

## Validación estática
- `node --check` sobre los 3 bloques JS y `sw.js`: PASS.
- JSON de manifest: PASS.
- - Prueba de navegador Android/Chrome real: pendiente; no se afirma como pasada.
