# NutriFamilia V7.0.0 — Auditoría final de overhaul visual + UX + lógica

## Objetivo
Transformación integral de la interfaz hacia una experiencia de app nutricional moderna, tomando como referencia de usabilidad la jerarquía visual de Fitia: calorías/objetivo visibles, macros juntos, comidas por bloques, registro rápido y buscador simple. No se copian identidad, logo, textos, gráficos ni código propietario.

## Cambios principales
- Dashboard de inicio con calorías consumidas/objetivo y progreso visual.
- Proteína, hidratos, grasas y fibra juntos en la cabecera nutricional.
- Comidas separadas por Desayuno, Almuerzo, Merienda, Cena y Snack.
- Acciones rápidas: agregar alimento, texto/voz, escáner y receta.
- Selector de alimentos rediseñado con búsqueda, Básicos, Favoritos, Recientes, Mis alimentos y Preparados.
- Los alimentos preparados dejan de contaminar la vista principal de ingredientes básicos; permanecen disponibles en la categoría Preparados para no romper históricos.
- Creación de alimentos personalizados visible desde el flujo principal.
- Unidades documentadas: el sistema utiliza unidad solamente cuando existe equivalencia en la ficha; el resto conserva gramos.
- Huevo crudo disponible por unidad mediante equivalencia de referencia registrada en la ficha.
- Recetas: 0 ingredientes iniciales, buscador, cantidad/unidad por ingrediente, eliminación individual y edición completa.
- Agua: +250 ml, -250 ml y edición directa.
- Código de barras: producto encontrado vuelve al flujo normal de agregar alimento.
- Voz/texto: interpretación local básica como alternativa a IA.
- Progreso: promedio de 7 días diferenciado del consumo del día y del gasto energético estimado.
- Service Worker/cache actualizado a V7.0.0.
- Namespace de datos se conserva para evitar pérdida de información al actualizar desde V6.6.6.

## Validación estática
- 3 bloques JavaScript sintácticamente válidos con `node --check`.
- Service Worker sintácticamente válido con `node --check`.
- Versión interna 7.0.0 consistente.
- Base declarada: 104 alimentos.
- Huevo crudo: 148 kcal, 12.4 g proteína, 1.0 g hidratos, 10.0 g grasa por 100 g; equivalencia registrada: 1 huevo sin cáscara = 50 g según la ficha utilizada.
- Sin migración automática desde namespaces anteriores.
- Sin clave `Authorization` embebida en la llamada de IA del cliente.

## Integridad nutricional
La app conserva el principio de no imputar micronutrientes ausentes como cero y mantiene fuentes/estado de calidad. Los datos de producto obtenidos por Open Food Facts se tratan como datos de etiqueta/producto y no como sustituto automático de una tabla científica.

## Limitación de validación de navegador
Chromium headless no completó la carga dentro del entorno de auditoría. Por lo tanto, esta versión se declara validada estáticamente y mediante los tests internos existentes, pero la validación final en GitHub Pages y dispositivo Android sigue siendo la prueba de aceptación de interfaz real.
