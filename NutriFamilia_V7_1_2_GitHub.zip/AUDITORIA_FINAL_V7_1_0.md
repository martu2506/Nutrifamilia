# Auditoría técnica — NutriFamilia V7.1.0

## Estado
**Resultado:** refactor estructural completado sobre V7.0.2.
**Objetivo:** eliminar el archivo monolítico de HTML/JS sin reescribir el producto ni alterar deliberadamente el modelo nutricional, la persistencia o las reglas existentes.

## Arquitectura resultante
- `index.html`: 2,4 KB; sin bloques `<style>` ni `<script>` inline.
- `css/`: 5 hojas separadas, manteniendo el orden de cascada de V7.0.2 para minimizar regresiones visuales.
- `js/data/nutrition-data.js`: alimentos, auditorías y referencias estáticas.
- `js/core/nutrition-engine.js`: objetivos, metadatos y reglas del motor.
- `js/core/storage.js`: estado, normalización, persistencia y perfiles.
- `js/core/data-io.js`: exportación/importación.
- `js/core/diagnostics.js`: autopruebas.
- `js/features/health.js`: agua, pasos, sueño y salud.
- `js/features/ai.js`: configuración y llamada a NutriIA.
- `js/features/voice.js`: entrada por voz y parser local.
- `js/features/ai-results.js`: resolución y gestión de resultados de IA.
- `js/features/meals.js`: comidas y edición de unidades.
- `js/features/recipes.js`: recetas.
- `js/ui/ui.js`: renderizado, navegación y pantallas.
- `js/compat.js`: compatibilidad final de la versión anterior.

## Compatibilidad
- Se conserva la clave `nutrifamilia_v6_6_6_standalone`; por tanto, el cambio de versión no obliga a crear un almacenamiento nuevo.
- La base de alimentos no fue modificada por el refactor.
- No se introdujeron valores nutricionales nuevos por inferencia.
- La IA continúa sin credenciales en cliente y el modelo es configurable por proxy.

## Validación automatizada
- `node --check`: PASS en todos los archivos JavaScript.
- Manifest JSON: PASS.
- Referencias locales de CSS/JS: PASS; todos los archivos referenciados existen.
- HTML: 0 estilos inline y 0 scripts inline.
- Se verificó que no quede el identificador público no verificado `gpt-5.6-luna` en el código de IA.

## Validación pendiente
La ejecución completa de Chromium headless en este entorno no terminó por limitaciones del entorno gráfico/DBus, por lo que **no se declara una prueba visual/runtime completa**. Antes de publicar se debe probar en GitHub Pages y en Android: alta de perfil, objetivos, agregar/editar/eliminar alimento, unidades del huevo, agua, peso, recetas, importación/exportación, voz/barcode cuando estén disponibles y autoprueba.

## Decisión de ingeniería
V7.1.0 es un **refactor, no una reescritura**. La separación permite modificar una función o feature sin volver a intervenir un `index.html` de ~190 KB. El siguiente cambio visual importante —incluido el medidor circular de calorías— debería implementarse sobre esta arquitectura modular.
