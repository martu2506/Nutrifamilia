NutriFamilia V2.2
Incluye autodiagnóstico interno para comprobar la lógica de perfiles, comidas, recetas, peso, agua, pasos y backup.
La autoprueba no sustituye la prueba real de instalación/UI en Android.
PWA completa requiere HTTPS o localhost.
