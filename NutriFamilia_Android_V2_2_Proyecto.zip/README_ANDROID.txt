NutriFamilia Android V2.2
=========================
Proyecto Android Studio completo que empaqueta NutriFamilia V2.2 como una app Android
local mediante WebView + WebViewAssetLoader.

Requisitos:
- Android Studio reciente
- JDK 17 (Android Studio lo incluye normalmente)
- Android SDK Platform 35
- Gradle se resuelve mediante Android Studio.

Abrir:
1) Android Studio -> Open -> seleccionar esta carpeta.
2) Esperar Gradle Sync.
3) Build -> Build APK(s).
4) APK debug: app/build/outputs/apk/debug/app-debug.apk

La aplicación carga todos los archivos desde assets; no necesita internet para funcionar.
Los datos de NutriFamilia permanecen en el almacenamiento local del WebView.
